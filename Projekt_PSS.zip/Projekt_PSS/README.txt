1.  Pobierz plik ZIP motywu
2.  Zaloguj się do panelu administracyjnego WordPressa:
3.  Przejdź do sekcji Motywy
4.  Dodaj nowy motyw
5.  Prześlij motyw
6.  Wybierz plik ZIP
7.  Zainstaluj i aktywuj

Dodatkowo w folderze zawarty jest folder image który zawiera plik MainPage.png przedstwiający podgląd motywu.
Znajduję się tutaj również folder wave images pokazujący badanie dostępności strony za pomocą wtyczki WAVE, która pozwala na testowanie zgodności z WCAG