<footer class="bg-dark text-white text-center py-3">
    <p>&copy; <?php echo date('Y'); ?> Portal dla graczy. Wszelkie prawa zastrzeżone.</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
